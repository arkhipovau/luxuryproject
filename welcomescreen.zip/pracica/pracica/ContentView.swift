//
//  ContentView.swift
//  pracica
//
//  Created by Ivan on 30.10.24..
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Welcome to the second screen!")
                .font(.largeTitle)
                .padding()
            Spacer()
        }
        .navigationTitle("Second Screen")
    }
}
