//
//  pracicaApp.swift
//  pracica
//
//  Created by Ivan on 30.10.24..
//

import SwiftUI

@main
struct pracicaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct WelcomeView: View {
    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading, spacing: -15) { // Align items to the left
                // Title
                Text("Welcome to")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(.white)
                    .tracking(-1.7) // letter spacing

                
                
                Text("Практики")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(.orange)
                    .tracking(-1.7) // letter spacing
                    .padding(.bottom, 16)
                
            
            // Subtitle
            Text("Медиа-сервис для поиска творческих идей и практик через истории")
                .font(.system(size: 17))
                .foregroundColor(.white)
                .tracking(-0.43) // Apply letter spacing
                .multilineTextAlignment(.leading) // Align text to the left
            
        }
            .padding(.horizontal, 50)
            
            
            Spacer()
            
            // Privacy Notice
            VStack(spacing: 8) { // Adjust spacing as needed
                // Centered Icon
                Image(systemName: "person.2.fill")
                    .foregroundColor(.orange)
                    .font(.system(size: 24)) // Adjust the size as needed

                // Privacy Notice Text
                Text("Apple collects your activity in Практики, which is not associated with your Apple ID, in order to improve and personalize Практики. When you turn on notifications for a channel, the channel can be associated with your Apple ID. Your device serial number may be used to check eligibility for service offers.")
                    .font(.system(size: 12))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                // Link Text
                    Link(destination: URL(string: "https://www.apple.com/privacy/")!) {
                        Text("See how your data is managed...")
                            .font(.system(size: 12))
                            .foregroundColor(.orange)
                            .underline()
                    }
                }
            .padding(.horizontal, 24) // Minimum 24 pixels padding on each side
                .padding(.bottom, 24)
            
            
            // Continue Button
                        Button(action: {
                            // Action for Continue button
                        }) {
                            Text("Продолжить")
                                .font(.system(size: 17, weight: .bold))
                                .foregroundColor(.white)
                                .frame(maxWidth: 288, minHeight: 50)
                                .background(Color.black)
                                .cornerRadius(14)
                                .padding(.horizontal, 20)
                        }
                        .padding(.bottom, 40)
        }
        .background(
            LinearGradient(
                gradient: Gradient(stops: [
                    Gradient.Stop(color: Color.black, location: 0.0),
                    Gradient.Stop(color: Color.black, location: 0.55), // 55% black
                    Gradient.Stop(color: Color.orange, location: 1.0) // Transition to orange at 100%
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
        )
        .ignoresSafeArea()
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
