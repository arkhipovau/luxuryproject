class CreateProjects < ActiveRecord::Migration[7.2]
  def change
    create_table :projects do |t|
      t.string :title
      t.text :description
      t.text :goals
      t.text :team_members

      t.timestamps
    end
  end
end
