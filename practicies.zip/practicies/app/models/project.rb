class Project < ApplicationRecord
end
