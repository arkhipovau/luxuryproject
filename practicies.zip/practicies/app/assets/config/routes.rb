Rails.application.routes.draw do
  get 'welcome/about', to: 'welcome#about'
  get 'welcome/promo', to: 'welcome#promo'  # Добавляем маршрут для promo.html.erb
end

