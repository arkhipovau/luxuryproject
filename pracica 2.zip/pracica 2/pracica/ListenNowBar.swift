//
//  ListenNowBar.swift
//  pracica
//
//  Created by Lucy Rez on 13.12.2024.
//

import Foundation
import SwiftUI

struct ListenNowBar: View {
    var body: some View {
        ZStack {
            
            Color(red: 40/255, green: 40/255, blue: 42/255)
                .opacity(0.94)
                .blur(radius: 50)
                .frame(height: 64)
            
            HStack {
                Image("pst")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 48, height: 48)
                    .cornerRadius(5)
                VStack(alignment: .leading) {
                    Text("Нейросети, панк и эстетики")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text("Октябрь 30")
                        .font(.system(size: 15))
                        .foregroundColor(Color(white: 0.6))
                }
                Spacer()
                Image(systemName: "play.fill")
                    .foregroundColor(.white)
                Image(systemName: "forward.fill")
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 20)
            

        }
    }
}

