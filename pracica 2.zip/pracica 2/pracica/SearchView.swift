//
//  SearchView.swift
//  pracica
//
//  Created by Lucy Rez on 13.12.2024.
//

import Foundation
import SwiftUI

struct SearchView: View {
    var body: some View {
        
        VStack {
            // Title Container
            VStack(alignment: .leading, spacing: 10) {
                Text("Поиск")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 32)
                SearchBar(text: .constant(""))
                    .padding(.bottom, 15)
                    
                Text("Категории")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.bottom, 10)
            }
           
            // Categories
            HStack(spacing: 10) {
                CategoryView(backgroundColor: Color(red: 184/255, green: 116/255, blue: 227/255), title: "Статьи")
                CategoryView(backgroundColor: Color(red: 227/255, green: 116/255, blue: 177/255), title: "Интервью")
            }
            .padding(.bottom, 10)
          
        
            HStack(spacing: 10) {
                CategoryView(backgroundColor: Color(red: 116/255, green: 220/255, blue: 227/255), title: "Подкасты")
                CategoryView(backgroundColor: Color(red: 227/255, green: 116/255, blue: 118/255), title: "Пины")
            }
            
            Spacer()
        }
        .padding(20)
       
    }
   
}
