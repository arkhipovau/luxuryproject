//
//  ScreenType.swift
//  pracica
//
//  Created by Lucy Rez on 13.12.2024.
//

import Foundation

enum ScreenType {
    case Home
    case Browse
    case Library
    case Search
}
