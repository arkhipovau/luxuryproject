import SwiftUI

struct WelcomeView: View {
    var body: some View {
        NavigationView { // Оборачиваем экран в NavigationView
            VStack {
                Spacer()
                
                VStack(alignment: .leading, spacing: -15) {
                    // Заголовки и описание
                    Text("Welcome to")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(.white)
                        .tracking(-1.7)
                    
                    Text("Практики")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(.orange)
                        .tracking(-1.7)
                        .padding(.bottom, 16)
                    
                    Text("Медиа-сервис для поиска творческих идей и практик через истории")
                        .font(.system(size: 17))
                        .foregroundColor(.white)
                        .tracking(-0.43)
                        .multilineTextAlignment(.leading)
                }
                .padding(.horizontal, 50)
                
                Spacer()
                
                // Приватность
                VStack(spacing: 8) {
                    Image(systemName: "person.2.fill")
                        .foregroundColor(.orange)
                        .font(.system(size: 24))
                    
                    Text("Apple collects your activity in Практики...")
                        .font(.system(size: 12))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                    
                    Link(destination: URL(string: "https://www.apple.com/privacy/")!) {
                        Text("See how your data is managed...")
                            .font(.system(size: 12))
                            .foregroundColor(.orange)
                            .underline()
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
                
                // NavigationLink для перехода
                NavigationLink(destination: ContentView()) {
                    Text("Продолжить")
                        .font(.system(size: 17, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: 288, minHeight: 50)
                        .background(Color.black)
                        .cornerRadius(14)
                        .padding(.horizontal, 20)
                }
                .padding(.bottom, 40)
            }
            .background(
                LinearGradient(
                    gradient: Gradient(stops: [
                        Gradient.Stop(color: Color.black, location: 0.0),
                        Gradient.Stop(color: Color.black, location: 0.55),
                        Gradient.Stop(color: Color.orange, location: 1.0)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            .ignoresSafeArea()
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
