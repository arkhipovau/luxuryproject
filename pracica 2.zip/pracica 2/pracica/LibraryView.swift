//
//  LibraryView.swift
//  pracica
//
//  Created by Lucy Rez on 13.12.2024.
//

import SwiftUI

struct LibraryView: View {
    var body: some View {
        // Library code
        Text("Library")
            .font(.system(size: 34, weight: .bold))
            .foregroundColor(.white)
            .padding(.top, 101)
    }
}

#Preview {
    LibraryView()
}
