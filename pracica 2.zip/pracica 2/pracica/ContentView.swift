
import SwiftUI


struct ContentView: View {
    @State var screenType: ScreenType = .Home
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .bottom) {
                
                VStack {
                    switch (screenType) {
                    case .Library :
                        SecondView()
                    case .Search:
                        SearchView()
                    default:
                        Text("Не реализовано")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 101)
                        
                    }
                    
                    Spacer()
                }
                
                
                // Listen Now Bar
                ListenNowBar()
                    .padding(10)
                    .padding(.top,32)
            }
            .padding(.horizontal, 20)

            
            
            // Tab Bar
            TabBar(selected: $screenType)
                .padding(.bottom, 24)
                .padding(.top, 8)
                .padding(.horizontal, 20)
            
            Spacer()
        }
        .navigationTitle("")
        .toolbar(.hidden)
        .background(Color.black)
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(red: 55/255, green: 55/255, blue: 57/255))
                .frame(height: 36)
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.white)
                Text("Поиск")
                    .foregroundColor(.white)
            }
            .padding(.leading, 6)
        }
        .opacity(0.5)
    }
}

struct CategoryView: View {
    var backgroundColor: Color
    var title: String
    
    var body: some View {
        VStack(alignment: .center) {
            Text(title)
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.white)
        }
        .padding(20)
        .padding(.bottom, -70)
        .frame(width: 180, height: 122)
        .background(backgroundColor)
        .cornerRadius(18)
        
    }
}



#Preview {
    ContentView()
}
