//
//  TabBar.swift
//  pracica
//
//  Created by Lucy Rez on 13.12.2024.
//

import Foundation
import SwiftUI

struct TabBar: View {
    @Binding var selected: ScreenType
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 50) {
                TabBarItem(icon: "house", title: "Главная", screenType: .Home, selected: $selected)
                   
                TabBarItem(icon: "square.grid.2x2", title: "Browse", screenType: .Browse, selected: $selected)
                   
                TabBarItem(icon: "books.vertical", title: "Library", screenType: .Library, selected: $selected)
                    
                TabBarItem(icon: "magnifyingglass", title: "Search", screenType: .Search, selected: $selected)
                   
            }
            .frame(maxWidth: .infinity)
       
        }
    }
}

struct HomeIndicator: View {
    var body: some View {
        Color.white
            .frame(width: 154, height: 5)
            .cornerRadius(100)
            .opacity(0.6)
            .blur(radius: 80)
            .padding(.bottom, 8)
    }
}

struct TabBarItem: View {
    var icon: String
    var title: String
    var screenType: ScreenType
    @Binding var selected: ScreenType
    
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.system(size: 23, weight: .semibold))
                .foregroundColor(selected == screenType ? Color.orange : Color.gray)
            Text(title)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(selected == screenType ? Color.orange : Color.gray)
        }
        .onTapGesture {
            selected = screenType
        }
    }
}
