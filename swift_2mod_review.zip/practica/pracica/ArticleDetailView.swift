import SwiftUI

struct ArticleDetailView: View {
    let title: String
    let time: String
    let content: String
    let imageName: String

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Изображение статьи
            Image(systemName: imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 200)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(.horizontal)

            // Заголовок статьи
            Text(title)
                .font(.title)
                .fontWeight(.bold)
                .padding(.horizontal)

            // Время публикации
            Text(time)
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.horizontal)

            // Контент статьи
            ScrollView {
                Text(content)
                    .font(.body)
                    .padding()
            }
            
            Spacer()
        }
        .navigationTitle("Детали статьи")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ArticleDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ArticleDetailView(
                title: "Creative thinking practices",
                time: "3 min ago",
                content: "This is the detailed content of the article. You can write as much text here as you want.",
                imageName: "circle.fill"
            )
        }
    }
}
