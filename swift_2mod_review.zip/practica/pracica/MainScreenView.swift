import SwiftUI

struct MainScreenView: View {
    @State private var selectedTab: String = "Лента"
    @State private var selectedContent: String = "Статьи"
    @State private var isShowingSearch = false // Состояние для отображения экрана поиска

    var body: some View {
        NavigationView {
            VStack(spacing: 0) { // Убираем динамическое пространство между компонентами
                if selectedTab == "Лента" {
                    VStack(spacing: 0) {
                        // Search Bar
                        HStack {
                            // Лупа
                            Button(action: {
                                isShowingSearch = true // Переход на экран поиска
                            }) {
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 20))
                                    .foregroundColor(.black)
                            }
                            .sheet(isPresented: $isShowingSearch) {
                                SearchView() // Экран поиска
                            }

                            Spacer()

                            // Настройки
                            Image(systemName: "gearshape")
                                .font(.system(size: 20))

                            // Аватарка
                            Rectangle()
                                .fill(Color.black)
                                .frame(width: 24, height: 24) // Аватарка
                        }
                        .padding(.horizontal, 8)
                        .frame(height: 40)
                        .padding(.top, 40)

                        // Tabs
                        HStack {
                            TabButton(title: "Статьи", isSelected: selectedContent == "Статьи") {
                                selectedContent = "Статьи"
                            }
                            .frame(maxWidth: .infinity)

                            TabButton(title: "Подкасты", isSelected: selectedContent == "Подкасты") {
                                selectedContent = "Подкасты"
                            }
                            .frame(maxWidth: .infinity)

                            TabButton(title: "Интервью", isSelected: selectedContent == "Интервью") {
                                selectedContent = "Интервью"
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .padding(.horizontal, 8)
                        .padding(.top, 60)

                        // Контент для выбранной вкладки
                        Group {
                            if selectedContent == "Статьи" {
                                ScrollView {
                                    LazyVGrid(columns: [
                                        GridItem(.fixed(187), spacing: 2),
                                        GridItem(.fixed(187), spacing: 2)
                                    ], spacing: 2) {
                                        ForEach(0..<20, id: \.self) { index in
                                            ArticleCard(
                                                time: "3 min ago",
                                                title: "Creative thinking practices \(index)",
                                                imageName: "circle.fill",
                                                content: "Detailed content of article \(index). This is the full article text."
                                            )
                                        }
                                    }
                                    .padding(.horizontal, 8)
                                    .padding(.top, 16)
                                }
                                .frame(height: 474) // Фиксированная высота
                            } else if selectedContent == "Подкасты" {
                                // Карточки подкастов
                                ScrollView {
                                    LazyVStack(spacing: 16) {
                                        PodcastCard(
                                            title: "Подкаст 1",
                                            description: "Описание.",
                                            duration: "40:25"
                                        )
                                        PodcastCard(
                                            title: "Подкаст 2",
                                            description: "Описание.",
                                            duration: "35:10"
                                        )
                                        PodcastCard(
                                            title: "Подкаст 3",
                                            description: "Описание.",
                                            duration: "45:00"
                                        )
                                    }
                                    .padding(.horizontal, 8)
                                    .padding(.top, 16)
                                }
                            } else {
                                Spacer()
                                Text("Пока нет контента для выбранной вкладки.")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)
                                Spacer()
                            }
                        }
                        .frame(maxHeight: .infinity) // Выравнивание контента
                    }
                    .frame(maxHeight: .infinity) // Фиксация высоты вкладки "Лента"
                } else if selectedTab == "Избранное" {
                    VStack {
                        Spacer()
                        Text("Пока нет контента для Избранного.")
                            .font(.system(size: 16))
                            .foregroundColor(.gray)
                        Spacer()
                    }
                    .frame(maxHeight: .infinity) // Фиксация высоты вкладки "Избранное"
                }

                // Таббар
                CustomTabBar(selectedTab: $selectedTab)
                    .frame(height: 68)
                    .padding(.bottom, 34)
            }
            .frame(maxHeight: .infinity) // Устанавливаем фиксированную высоту для основного VStack
            .edgesIgnoringSafeArea(.bottom)
        }
    }
}

struct MainScreenView_Previews: PreviewProvider {
    static var previews: some View {
        MainScreenView()
    }
}
