import SwiftUI

struct SearchView: View {
    @Environment(\.presentationMode) var presentationMode // Для закрытия экрана
    @State private var searchText = "" // Текст поиска
    @State private var searchResults: [String] = [] // Результаты поиска
    let allArticles = [
        "Creative Thinking Practices",
        "123",
        "Test"
    ] // Статьи

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)

                        TextField("Поиск", text: $searchText, onEditingChanged: { _ in
                            performSearch()
                        })
                        .textFieldStyle(PlainTextFieldStyle())

                        if !searchText.isEmpty {
                            Button(action: {
                                searchText = ""
                                searchResults = []
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(8)
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                    Button("Отмена") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .foregroundColor(.blue)
                }
                .padding(.horizontal)
                .padding(.top, 10)

                // Результаты поиска
                if searchResults.isEmpty {
                    if searchText.isEmpty {
                        Spacer()
                        Text("Введите запрос для поиска статей")
                            .font(.body)
                            .foregroundColor(.gray)
                        Spacer()
                    } else {
                        Spacer()
                        Text("Ничего не найдено")
                            .font(.body)
                            .foregroundColor(.gray)
                        Spacer()
                    }
                } else {
                    List(searchResults, id: \.self) { article in
                        NavigationLink(
                            destination: ArticleDetailView(
                                title: article,
                                time: "3 min ago",
                                content: "This is the detailed content of the article '\(article)'.",
                                imageName: "circle.fill"
                            )
                        ) {
                            VStack(alignment: .leading) {
                                Text(article)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text("3 min ago")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .listStyle(InsetGroupedListStyle())
                }
            }
            .navigationBarHidden(true) // Скрываем стандартную навигацию
        }
    }

    // Функция поиска
    func performSearch() {
        if searchText.isEmpty {
            searchResults = []
        } else {
            searchResults = allArticles.filter {
                $0.lowercased().contains(searchText.lowercased())
            }
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SearchView()
        }
    }
}
