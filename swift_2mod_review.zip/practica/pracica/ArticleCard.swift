import SwiftUI

struct ArticleCard: View {
    let time: String
    let title: String
    let imageName: String
    let content: String

    var body: some View {
        NavigationLink(destination: ArticleDetailView(
            title: title,
            time: time,
            content: content,
            imageName: imageName
        )) {
            VStack(alignment: .leading, spacing: 8) {
                // Время публикации
                Text(time)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)

                // Заголовок статьи
                Text(title)
                    .font(.system(size: 16))
                    .foregroundColor(.black)
                    .lineLimit(2)

                Spacer()

                // Изображение статьи
                Image(systemName: imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 144, height: 144)
                    .clipShape(Circle())
                    .padding(8)
            }
            .padding(8)
            .frame(width: 187, height: 236)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
        .buttonStyle(PlainButtonStyle()) // Убираем стандартный стиль кнопки
    }
}
