import SwiftUI

struct PodcastCard: View {
    let title: String
    let description: String
    let duration: String

    var body: some View {
        HStack(spacing: 16) {
            // Иконка подкаста
            Image(systemName: "headphones")
                .resizable()
                .scaledToFit()
                .frame(width: 50, height: 50)
                .padding(8)
                .background(Color(.systemGray5))
                .cornerRadius(10)

            // Текстовая информация
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .lineLimit(1)

                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(2)

                Text(duration)
                    .font(.footnote)
                    .foregroundColor(.gray)
            }

            Spacer()

            // Кнопка воспроизведения
            Button(action: {
            }) {
                Image(systemName: "play.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.blue)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color(.systemGray4), radius: 4, x: 0, y: 2)
    }
}

struct PodcastCard_Previews: PreviewProvider {
    static var previews: some View {
        PodcastCard(
            title: "Название подкаста",
            description: "Краткое описание подкаста, которое может занимать две строки.",
            duration: "40:25"
        )
        .previewLayout(.sizeThatFits)
        .padding()
    }
}
