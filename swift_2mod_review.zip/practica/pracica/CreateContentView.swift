import SwiftUI

struct CreateContentView: View {
    @Environment(\.presentationMode) var presentationMode // Для закрытия экрана
    @State private var title: String = "" // Заголовок контента
    @State private var description: String = "" // Описание контента

    var body: some View {
        NavigationView {
            VStack {
                // Поле ввода заголовка
                TextField("Заголовок", text: $title)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)

                // Поле ввода описания
                TextEditor(text: $description)
                    .frame(height: 200)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)

                Spacer()

                // Кнопка "Создать"
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Text("Создать")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .padding(.horizontal)
                }
                .padding(.bottom, 16)
            }
            .navigationBarTitle("Создать контент", displayMode: .inline)
            .navigationBarItems(
                trailing: Button("Отмена") {
                    presentationMode.wrappedValue.dismiss()
                }
                .foregroundColor(.blue)
            )
        }
    }
}

struct CreateContentView_Previews: PreviewProvider {
    static var previews: some View {
        CreateContentView()
    }
}
