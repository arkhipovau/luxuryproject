import SwiftUI

struct WelcomeView: View {
    @State private var isActive = false // Управление переходом на MainScreenView

    var body: some View {
        if isActive {
            MainScreenView() // Переход на главный экран
        } else {
            ZStack {
                // Фон экрана
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)

                // Основное содержимое
                VStack {
                    Spacer()

                    // Текст Welcome
                    Text("Welcome")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding(.bottom, 40) // Отступ от нижнего края

                    Spacer()
                }
            }
            .onAppear {
                // Таймер на 2 секунды
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation {
                        isActive = true // Активируем переход
                    }
                }
            }
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
