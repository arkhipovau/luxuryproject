import SwiftUI

struct CustomTabBar: View {
    @Binding var selectedTab: String // Привязка для активной вкладки
    @State private var isPresentingCreateContent = false // Состояние для отображения CreateContentView

    var body: some View {
        HStack {
            // Кнопка "Избранное"
            Button(action: {
                selectedTab = "Избранное"
            }) {
                Text("Избранное")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(selectedTab == "Избранное" ? .black : .gray)
                    .frame(width: 98, height: 44)
            }

            Spacer()

            // Центральная кнопка "+"
            Button(action: {
                isPresentingCreateContent = true // Показать CreateContentView
            }) {
                Image(systemName: "plus")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
                    .frame(width: 64, height: 44)
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .sheet(isPresented: $isPresentingCreateContent) {
                CreateContentView() // Экран создания контента
            }

            Spacer()

            // Кнопка "Лента"
            Button(action: {
                selectedTab = "Лента"
            }) {
                Text("Лента")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(selectedTab == "Лента" ? .black : .gray)
                    .frame(width: 98, height: 44)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(width: 393, height: 68)
        .background(Color.white)
    }
}

struct CustomTabBar_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabBar(selectedTab: .constant("Лента"))
    }
}
