import SwiftUI

@main
struct pracicaApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView() // Указываем начальный экран
        }
    }
}
